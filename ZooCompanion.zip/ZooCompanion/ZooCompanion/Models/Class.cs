﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ZooCompanion.Models
{
    public class Class
    {
        public int ClassId { get; set; }
        public string Name { get; set; }
    }
}
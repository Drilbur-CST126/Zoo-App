﻿namespace AdminPortalTests
{

    public partial class UIMap
    {
    }
}
